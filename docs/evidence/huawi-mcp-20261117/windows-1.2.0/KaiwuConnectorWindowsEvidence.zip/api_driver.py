#!/usr/bin/env python3
"""Drive the local Kaiwu connector API for acceptance evidence."""

import json
import re
import sys
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:17872"


def get_token() -> str:
    with urllib.request.urlopen(BASE + "/", timeout=10) as resp:
        html = resp.read().decode("utf-8", errors="replace")
    match = re.search(r'const TOKEN = "([0-9a-f]{48})";', html)
    if not match:
        raise SystemExit("token not found in page")
    return match.group(1)


def post(path: str, payload: dict, token: str) -> dict:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        BASE + path,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Connector-Token": token,
        },
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get(path: str) -> dict:
    with urllib.request.urlopen(BASE + path, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def get_auth(path: str, token: str) -> dict:
    req = urllib.request.Request(BASE + path, headers={"X-Connector-Token": token})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return json.loads(exc.read().decode("utf-8"))


def main() -> int:
    token = get_token()
    command = sys.argv[1] if len(sys.argv) > 1 else "status"
    if command == "status":
        result = get("/api/status")
    elif command == "import":
        with open(sys.argv[2], encoding="utf-8") as handle:
            config = handle.read()
        result = post("/api/import", {"config": config}, token)
    elif command == "diagnose":
        probe = sys.argv[2] if len(sys.argv) > 2 else ""
        result = post("/api/diagnose", {"tool_probe": probe}, token)
    elif command == "auth":
        result = post("/api/auth-profile", {
            "source_id": sys.argv[2],
            "app_id": sys.argv[3],
            "channel": sys.argv[4],
            "user_id": sys.argv[5],
            "hmac_key": sys.argv[6],
            "tools": sys.argv[7],
        }, token)
    elif command == "export":
        result = get_auth("/api/export", token)
    else:
        raise SystemExit("unknown command: " + command)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
