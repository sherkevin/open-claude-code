#!/usr/bin/env python3
"""Minimal Streamable HTTP MCP server for Windows connector testing."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import json

AUTH_HEADER = "Bearer demo-token-123"
TOOL_NAME = "get_inventory"


class Handler(BaseHTTPRequestHandler):
    server_version = "KaiwuMockMCP/1.0"

    def log_message(self, fmt, *args):
        print(f"{self.log_date_time_string()} {fmt % args}", flush=True)

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path != "/mcp":
            self.send_json(404, {"error": "not found"})
            return
        if self.headers.get("Authorization", "") != AUTH_HEADER:
            self.send_json(401, {"error": "unauthorized"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            request = json.loads(self.rfile.read(length))
        except Exception as exc:
            self.send_json(400, {"error": f"invalid JSON: {exc}"})
            return

        method = request.get("method")
        request_id = request.get("id")

        if method == "notifications/initialized":
            self.send_response(202)
            self.end_headers()
            return

        if method == "initialize":
            result = {
                "protocolVersion": "2025-06-18",
                "capabilities": {"tools": {}},
                "serverInfo": {
                    "name": "kaiwu-mock-inventory",
                    "version": "1.0.0",
                },
            }
        elif method == "tools/list":
            result = {
                "tools": [
                    {
                        "name": TOOL_NAME,
                        "description": "Return deterministic demo inventory rows",
                        "inputSchema": {
                            "type": "object",
                            "properties": {
                                "warehouse": {
                                    "type": "string",
                                    "description": "warehouse code",
                                }
                            },
                            "additionalProperties": False,
                        },
                    }
                ]
            }
        elif method == "tools/call":
            params = request.get("params") or {}
            if params.get("name") != TOOL_NAME:
                self.send_json(
                    200,
                    {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "error": {
                            "code": -32601,
                            "message": "unknown tool",
                        },
                    },
                )
                return
            result = {
                "content": [
                    {
                        "type": "text",
                        "text": "仓库 A：SKU-1001 库存 42；SKU-2002 库存 17",
                    }
                ]
            }
        else:
            self.send_json(
                200,
                {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32601,
                        "message": f"unknown method: {method}",
                    },
                },
            )
            return

        self.send_json(
            200,
            {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result,
            },
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=28765)
    args = parser.parse_args()
    print(f"Mock MCP listening on http://{args.host}:{args.port}/mcp", flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()
