# 第一次服务重启后的 401 观察（测试记录，非确认产品缺陷）

时间：2026-11-17 20:41

## 现象

- 在完成错误凭据 → 恢复正确凭据的页面操作后，第一次执行 `Restart-Service -Name KaiwuConnector -Force`。
- 重启后 `POST /mcp` 返回 401；`/api/diagnose` 的 `protocol` 检查失败，错误为 `UPSTREAM_AUTH_FAILED` / HTTP 401。
- 随后用 API 重新导入同一份正确配置（`mcp-import-demo.json`），诊断恢复通过。
- 20:46:57 做第二次干净重启，服务 Running、状态 `CONFIGURING`、来源/`tool_allowlist`/`auth_profiles` 均保留，诊断和 `get_inventory` 试调用通过。

## 证据

- `mock-mcp.log`：20:41:33 有一条 `POST /mcp 401`。
- `import-after-restart-fix.json`：API 重新导入正确配置。
- `diagnose-after-restart-fix.json`：重新导入后诊断通过。
- `status-after-restart-clean.json`：干净重启后状态。
- `diagnose-after-restart.json`、`diagnose-tool-after-restart.json`：干净重启后诊断/试调用通过。

## 结论

这是一次测试序列观察，暂不判定为确认的产品缺陷。可能原因是页面导入请求在该浏览器会话中没有正确写入 `Authorization` secret，或自动化填充/提交时序导致提交了旧值。建议开发用人工浏览器复现：错误凭据 → 恢复 → 重启 → 诊断，并检查 `/api/import` 写入 `secrets.json` 的路径和页面提交时序。
