# D01 重新导入 MCP 配置后动态认证工具允许列表被清空

- 版本：`kaiwu-connector 1.2.0`，commit `b26e131`
- 严重度：中（不影响本次 A/B 的正常诊断结论；影响 1.2.0 新增的本机动态认证工具试调用）
- 发现方式：测试中复现 + 源码核对

## 复现步骤

1. 在第 2 步导入 `mcpServers` 配置（来源 `src_4853fc5ee3cc19cfc68f0d9e1751bf35`）。
2. 在第 3 步配置本机动态认证，允许工具填 `get_inventory`。
3. 重新导入同一份 `mcpServers` 配置（例如从错误凭据恢复正确凭据）。
4. 调用 `/api/diagnose`，带 `tool_probe=get_inventory`。
5. 观察到：`auth_profiles[0].configured=true`，但 `allowed_tools=[]`，`source.tool_allowlist=[]`；诊断返回 400 / “试调用工具不在客户允许列表内”。
6. 重新保存第 3 步动态认证（或调用 `/api/auth-profile` 重新写入 `get_inventory`）后，试调用恢复通过。

## 源码位置

- `connector/internal/agent/agent.go` `ImportConfig`：`a.config.Sources = report.Sources`，新导入的 source 不带 `ToolAllowlist`；`a.profiles` 仍保留。
- `connector/internal/agent/auth_profile.go` `authStatusLocked`：`allowed := source.ToolAllowlist`，所以状态显示“已配置”但允许工具为空。
- `connector/internal/agent/agent.go` `Diagnose`：`if probe != "" && !containsTool(source.ToolAllowlist, probe)` 直接拒绝。

## 建议修复

- 重新导入时按稳定 `source_id` 合并/保留原有 `ToolAllowlist`；或者
- 当允许列表被清空时同时清除该 source 的 profile，避免显示“已配置”；或者
- UI 明确提示“重新导入后需要重新确认允许工具”，不要让用户看到“已配置”却无法试调用。
